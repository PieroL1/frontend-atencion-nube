import { NavLink, useNavigate } from 'react-router-dom';
import { getUser, getRole, logout } from '../auth';
// ...
const role = getRole();
// ...
<nav className="hidden lg:flex items-center gap-1 ml-4">
  {role === 'student' && (
    <>
      <NavLink to="/dashboard" className={linkCls}>Dashboard</NavLink>
      <NavLink to="/atencion"  className={linkCls}>Atención</NavLink>
      <NavLink to="/orientacion" className={linkCls}>Orientación</NavLink>
      <NavLink to="/bienestar" className={linkCls}>Bienestar</NavLink>
      <NavLink to="/reclamos" className={linkCls}>Reclamos</NavLink>
      <NavLink to="/comunidad" className={linkCls}>Comunidad</NavLink>
    </>
  )}
  {role === 'employee' && (
    <>
      <NavLink to="/employee" className={linkCls}>Panel</NavLink>
      <NavLink to="/atencion" className={linkCls}>Atenciones</NavLink>
      <NavLink to="/reclamos" className={linkCls}>Reclamos</NavLink>
      {/* agrega reportes, bandeja, etc. */}
    </>
  )}
</nav>
